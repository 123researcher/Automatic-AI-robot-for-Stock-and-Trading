# incomplete-trading-bot
 More at www.theincompleteguide.com
 
 This code is free, THANK YOU!
 It is explained at the guide you can found at www.theincompleteguide.com
 You will also find improvement, ideas and explanations
 You can buy it there, or donate. There's been effort here.
